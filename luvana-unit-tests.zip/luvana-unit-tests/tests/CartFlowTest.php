<?php

declare(strict_types=1);

require_once __DIR__ . '/DatabaseTestCase.php';

final class CartFlowTest extends DatabaseTestCase
{
    public function testAddNewCustomizedProductToCart(): void
    {
        $userId = $this->createUser();
        $productId = $this->getProductIdByName('Charcoal Detox Bar');

        $this->addToCart($userId, $productId, 2, 'Black', 'Square');

        $row = $this->db->query('SELECT product_id, quantity, color, shape, status FROM cart')->fetch_assoc();

        self::assertSame($productId, (int) $row['product_id']);
        self::assertSame(2, (int) $row['quantity']);
        self::assertSame('Black', $row['color']);
        self::assertSame('Square', $row['shape']);
        self::assertSame('active', $row['status']);
    }

    public function testAddingSameCustomizedProductIncreasesQuantity(): void
    {
        $userId = $this->createUser();
        $productId = $this->getProductIdByName('Rose Bloom Soap');

        $this->addToCart($userId, $productId, 1, 'Red', 'Floral');
        $this->addToCart($userId, $productId, 3, 'Red', 'Floral');

        $row = $this->db->query('SELECT COUNT(*) AS rows_count, SUM(quantity) AS total_qty FROM cart')->fetch_assoc();

        self::assertSame(1, (int) $row['rows_count']);
        self::assertSame(4, (int) $row['total_qty']);
    }

    public function testDifferentCustomizationCreatesSeparateCartRow(): void
    {
        $userId = $this->createUser();
        $productId = $this->getProductIdByName('Neem Cleanse Bar');

        $this->addToCart($userId, $productId, 1, 'Green', 'Circle');
        $this->addToCart($userId, $productId, 1, 'Green', 'Bubble');

        $row = $this->db->query('SELECT COUNT(*) AS rows_count FROM cart')->fetch_assoc();

        self::assertSame(2, (int) $row['rows_count']);
    }

    public function testCheckoutTotalIncludesOnlyActiveCartItems(): void
    {
        $userId = $this->createUser();
        $roseId = $this->getProductIdByName('Rose Bloom Soap');
        $neemId = $this->getProductIdByName('Neem Cleanse Bar');

        $this->addToCart($userId, $roseId, 2, 'Red', 'Floral');
        $this->addToCart($userId, $neemId, 1, 'Green', 'Circle');
        $this->db->query("UPDATE cart SET status = 'cancelled' WHERE product_id = $neemId");

        self::assertSame(1100.00, $this->checkoutTotal($userId));
    }

    public function testCancelOnlyChangesTheSelectedUsersCartRow(): void
    {
        $userOne = $this->createUser('one@example.com');
        $userTwo = $this->createUser('two@example.com');
        $productId = $this->getProductIdByName('Massage Soap Bar');

        $cartOne = $this->addToCart($userOne, $productId, 1, 'Lavender', 'Circle');
        $cartTwo = $this->addToCart($userTwo, $productId, 1, 'Lavender', 'Circle');

        $this->cancelCartItem($cartOne, $userOne);

        $statusOne = $this->cartStatus($cartOne);
        $statusTwo = $this->cartStatus($cartTwo);

        self::assertSame('cancelled', $statusOne);
        self::assertSame('active', $statusTwo);
    }

    public function testPaymentMarksActiveCartItemsAsPaid(): void
    {
        $userId = $this->createUser();
        $productId = $this->getProductIdByName('Charcoal Detox Bar');

        $this->addToCart($userId, $productId, 1, 'Black', 'Square');
        $this->markCartPaid($userId);

        self::assertSame('paid', $this->db->query('SELECT status FROM cart')->fetch_assoc()['status']);
    }

    private function addToCart(int $userId, int $productId, int $quantity = 1, string $color = 'Default', string $shape = 'Default'): int
    {
        $stmt = $this->db->prepare(
            "SELECT id FROM cart WHERE user_id = ? AND product_id = ? AND color = ? AND shape = ? AND status = 'active'"
        );
        $stmt->bind_param('iiss', $userId, $productId, $color, $shape);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();

        if ($existing) {
            $cartId = (int) $existing['id'];
            $update = $this->db->prepare('UPDATE cart SET quantity = quantity + ? WHERE id = ?');
            $update->bind_param('ii', $quantity, $cartId);
            $update->execute();
            return $cartId;
        }

        $insert = $this->db->prepare(
            "INSERT INTO cart (user_id, product_id, quantity, color, shape, status) VALUES (?, ?, ?, ?, ?, 'active')"
        );
        $insert->bind_param('iiiss', $userId, $productId, $quantity, $color, $shape);
        $insert->execute();

        return (int) $this->db->insert_id;
    }

    private function cancelCartItem(int $cartId, int $userId): void
    {
        $stmt = $this->db->prepare("UPDATE cart SET status = 'cancelled' WHERE id = ? AND user_id = ?");
        $stmt->bind_param('ii', $cartId, $userId);
        $stmt->execute();
    }

    private function markCartPaid(int $userId): void
    {
        $stmt = $this->db->prepare("UPDATE cart SET status = 'paid' WHERE user_id = ? AND status = 'active'");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
    }

    private function checkoutTotal(int $userId): float
    {
        $stmt = $this->db->prepare(
            "SELECT SUM(products.price * cart.quantity) AS total
             FROM cart
             JOIN products ON cart.product_id = products.id
             WHERE cart.user_id = ? AND cart.status = 'active'"
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        return (float) ($row['total'] ?? 0);
    }

    private function cartStatus(int $cartId): string
    {
        $stmt = $this->db->prepare('SELECT status FROM cart WHERE id = ?');
        $stmt->bind_param('i', $cartId);
        $stmt->execute();

        return $stmt->get_result()->fetch_assoc()['status'];
    }
}
