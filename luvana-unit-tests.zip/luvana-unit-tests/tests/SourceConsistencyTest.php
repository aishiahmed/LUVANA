<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class SourceConsistencyTest extends TestCase
{
    public function testCancelItemUsesAllowedCancelledStatus(): void
    {
        $source = $this->readProjectFile('cancel_item.php');

        self::assertStringContainsString(
            "status = 'cancelled'",
            $source,
            "Your cart enum uses 'cancelled'. Change cancel_item.php from 'canceled' to 'cancelled', or update the enum consistently."
        );
    }

    public function testPaymentProcessUsesAllowedPaidStatus(): void
    {
        $source = $this->readProjectFile('payment_process.php');

        self::assertStringContainsString(
            "status = 'paid'",
            $source,
            "Your cart enum uses 'paid'. Change payment_process.php from 'ordered' to 'paid', or update the enum consistently."
        );
    }

    public function testCheckoutCallsPaymentProcessBeforeSuccessPage(): void
    {
        $source = $this->readProjectFile('checkout.php');

        self::assertStringContainsString(
            'payment_process.php',
            $source,
            'checkout.php currently redirects straight to success.php, so the cart status may never be updated.'
        );
    }

    private function readProjectFile(string $file): string
    {
        $path = PROJECT_ROOT . '/' . $file;
        self::assertFileExists($path, "Copy the tests folder into the same parent folder as $file.");

        $source = file_get_contents($path);
        self::assertIsString($source);

        return $source;
    }
}
