<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class MoodSuggestionTest extends TestCase
{
    public function testStressedMoodRecommendsRoseBloomSoap(): void
    {
        $_POST['mood'] = 'stressed';

        ob_start();
        include PROJECT_ROOT . '/mood_suggestion.php';
        $html = ob_get_clean();

        self::assertStringContainsString('Rose Bloom Soap', $html);
        self::assertStringContainsString('rose', $html);
    }

    public function testFreshMoodRecommendsNeemCleanseBar(): void
    {
        $_POST['mood'] = 'fresh';

        ob_start();
        include PROJECT_ROOT . '/mood_suggestion.php';
        $html = ob_get_clean();

        self::assertStringContainsString('Neem Cleanse Bar', $html);
        self::assertStringContainsString('neem', $html);
    }

    protected function tearDown(): void
    {
        unset($_POST['mood']);
        parent::tearDown();
    }
}
