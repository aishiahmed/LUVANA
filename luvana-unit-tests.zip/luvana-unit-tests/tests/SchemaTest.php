<?php

declare(strict_types=1);

require_once __DIR__ . '/DatabaseTestCase.php';

final class SchemaTest extends DatabaseTestCase
{
    public function testUsersTableMatchesPhpCode(): void
    {
        $columns = $this->columnNames('users');

        self::assertContains('id', $columns);
        self::assertContains('google_id', $columns);
        self::assertContains('username', $columns, 'PHP uses users.username in register/login/google login.');
        self::assertContains('email', $columns);
        self::assertContains('password', $columns);
        self::assertContains('role', $columns, 'PHP checks $_SESSION[role] and SELECTs users.role.');
        self::assertContains('created_at', $columns);
    }

    public function testProductsTableMatchesPhpCode(): void
    {
        $columns = $this->columnNames('products');

        self::assertContains('id', $columns);
        self::assertContains('name', $columns);
        self::assertContains('price', $columns);
        self::assertContains('image_url', $columns, 'products.php and admin.php read products.image_url.');
        self::assertContains('description', $columns);
    }

    public function testCartStatusEnumUsesApplicationStates(): void
    {
        $row = $this->db->query("SHOW COLUMNS FROM cart LIKE 'status'")->fetch_assoc();

        self::assertSame("enum('active','paid','cancelled')", $row['Type']);
    }

    public function testSampleProductsAreSeeded(): void
    {
        $count = (int) $this->db->query('SELECT COUNT(*) AS total FROM products')->fetch_assoc()['total'];

        self::assertSame(4, $count);
    }

    private function columnNames(string $table): array
    {
        $result = $this->db->query("SHOW COLUMNS FROM `$table`");
        $columns = [];

        while ($row = $result->fetch_assoc()) {
            $columns[] = $row['Field'];
        }

        return $columns;
    }
}
