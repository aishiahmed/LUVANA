<?php

declare(strict_types=1);

require_once __DIR__ . '/DatabaseTestCase.php';

final class AuthTest extends DatabaseTestCase
{
    public function testRegistrationStoresHashedPassword(): void
    {
        $plainPassword = 'roseSecret123';
        $hash = password_hash($plainPassword, PASSWORD_DEFAULT);

        $stmt = $this->db->prepare(
            'INSERT INTO users (username, email, password) VALUES (?, ?, ?)'
        );
        $username = 'Rose Customer';
        $email = 'rose@example.com';
        $stmt->bind_param('sss', $username, $email, $hash);
        $stmt->execute();

        $row = $this->db->query("SELECT username, email, password, role FROM users WHERE email = 'rose@example.com'")
            ->fetch_assoc();

        self::assertSame('Rose Customer', $row['username']);
        self::assertSame('rose@example.com', $row['email']);
        self::assertNotSame($plainPassword, $row['password']);
        self::assertTrue(password_verify($plainPassword, $row['password']));
        self::assertSame('customer', $row['role']);
    }

    public function testDuplicateEmailCannotRegisterTwice(): void
    {
        $this->createUser('duplicate@example.com');

        $this->expectException(mysqli_sql_exception::class);
        $this->createUser('duplicate@example.com');
    }

    public function testAdminLoginDataCanBeRead(): void
    {
        $adminId = $this->createUser('admin@example.com', 'admin');

        $stmt = $this->db->prepare('SELECT id, username, password, role FROM users WHERE email = ?');
        $email = 'admin@example.com';
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        self::assertSame($adminId, (int) $row['id']);
        self::assertTrue(password_verify('secret123', $row['password']));
        self::assertSame('admin', $row['role']);
    }
}
