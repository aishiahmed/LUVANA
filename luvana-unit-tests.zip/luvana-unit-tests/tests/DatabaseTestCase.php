<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

abstract class DatabaseTestCase extends TestCase
{
    protected mysqli $db;

    protected function setUp(): void
    {
        parent::setUp();

        $host = getenv('LUVANA_TEST_DB_HOST') ?: '127.0.0.1';
        $user = getenv('LUVANA_TEST_DB_USER') ?: 'root';
        $pass = getenv('LUVANA_TEST_DB_PASS') ?: '';
        $name = getenv('LUVANA_TEST_DB_NAME') ?: 'luvana_test_db';

        $server = new mysqli($host, $user, $pass);
        $server->query("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $server->close();

        $this->db = new mysqli($host, $user, $pass, $name);
        $this->db->set_charset('utf8mb4');
        $this->loadSchema();
    }

    protected function tearDown(): void
    {
        if (isset($this->db)) {
            $this->db->close();
        }

        parent::tearDown();
    }

    private function loadSchema(): void
    {
        $schema = file_get_contents(PROJECT_ROOT . '/sql/schema_test.sql');
        if ($schema === false) {
            self::fail('Could not read sql/schema_test.sql');
        }

        $this->db->multi_query($schema);
        do {
            if ($result = $this->db->store_result()) {
                $result->free();
            }
        } while ($this->db->more_results() && $this->db->next_result());
    }

    protected function createUser(string $email = 'customer@example.com', string $role = 'customer'): int
    {
        $passwordHash = password_hash('secret123', PASSWORD_DEFAULT);
        $stmt = $this->db->prepare(
            'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)'
        );
        $name = ucfirst($role) . ' User';
        $stmt->bind_param('ssss', $name, $email, $passwordHash, $role);
        $stmt->execute();

        return (int) $this->db->insert_id;
    }

    protected function getProductIdByName(string $name): int
    {
        $stmt = $this->db->prepare('SELECT id FROM products WHERE name = ?');
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        self::assertNotNull($row, "Missing seeded product: $name");
        return (int) $row['id'];
    }
}
