# Luvana PHPUnit Test Suite

This folder contains PHPUnit tests for the Luvana PHP/MySQL project.

## What this tests

- Database schema matches your PHP code.
- Registration stores a hashed password and rejects duplicate emails.
- Cart flow: add item, merge same customization, separate different customization, cancel item, checkout total, and paid status.
- Mood suggestion page output.
- Source-code consistency checks for cart status values.

## Important fixes before running all tests

Your current PHP code has a few mismatches. Apply these first if you want the full suite to pass:

1. In `cancel_item.php`, change:

```php
status = 'canceled'
```

to:

```php
status = 'cancelled'
```

2. In `payment_process.php`, change:

```php
status = 'ordered'
```

to:

```php
status = 'paid'
```

3. In `checkout.php`, the JavaScript currently sends users directly to `success.php`. Submit/post to `payment_process.php` first so the database status changes to `paid`.

4. Your schema should use `username`, `role`, `google_id`, and `image_url` because the PHP files use those names.

## Install and run

From the project root, copy these files into your project:

```text
composer.json
phpunit.xml
sql/schema_test.sql
tests/
```

Then run:

```bash
composer install
vendor/bin/phpunit
```

If you use XAMPP, make sure MySQL is running. The test suite creates and resets a separate database named `luvana_test_db`, so it will not erase your main app database.

If your MySQL username/password is different, edit `phpunit.xml`.
